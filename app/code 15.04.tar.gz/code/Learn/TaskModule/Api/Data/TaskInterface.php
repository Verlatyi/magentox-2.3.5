<?php

namespace Learn\TaskModule\Api\Data;

/**
 * @api
 */
interface TaskInterface
{

}
