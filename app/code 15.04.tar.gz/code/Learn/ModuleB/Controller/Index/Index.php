<?php

namespace Learn\ModuleB\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Learn\ModuleA\Api\BoatInterface;

class Index extends Action
{
    protected $boatInterface;

    public function __construct(
        Context $context,
        BoatInterface $boatInterface
    ) {
        $this->boatInterface = $boatInterface;
        parent::__construct($context);
    }

    public function execute()
    {
        echo "<pre>";
        echo $this->boatInterface->getBoatType();
    }
}
