<?php


namespace Learn\BigBoats\Api;


interface Color
{
    public function getColor();
}
