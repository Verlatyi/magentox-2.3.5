<?php


namespace Learn\BigBoats\Api;


interface Covering
{

}
