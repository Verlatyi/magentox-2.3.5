<?php

namespace Learn\BigBoats\Api;

interface BoatInterface
{
    public function getBoatType();

    public function getBoatColor();
}