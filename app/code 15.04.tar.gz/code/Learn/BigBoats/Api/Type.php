<?php


namespace Learn\BigBoats\Api;


interface Type
{
    public function getType();
}
