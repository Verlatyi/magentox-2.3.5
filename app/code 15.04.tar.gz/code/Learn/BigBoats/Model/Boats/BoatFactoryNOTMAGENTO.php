<?php

namespace Learn\BigBoats\Model\Boats;

//use Magento\Framework\ObjectManagerInterface;

//class BoatFactory
//{
//    private $objectManager;
//
//    /**
//     * BoatFactory constructor.
//     * @param ObjectManagerInterface $objectManager
//     */
//    public function __construct(ObjectManagerInterface $objectManager)
//    {
//        $this->objectManager = $objectManager;
//    }
//
//    /**
//     * @param array $data
//     * @return Boat
//     */
//    public function create(array $data)
//    {
//        return $this->objectManager->create('Learn\BigBoats\Api\BoatInterface', $data);
//    }
//}
