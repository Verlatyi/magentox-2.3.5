<?php

namespace Learn\BigBoats\Model\Coverings;

use Learn\BigBoats\Api\Covering;

class Matt implements Covering
{

}
