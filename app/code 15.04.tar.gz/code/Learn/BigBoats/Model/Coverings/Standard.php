<?php


namespace Learn\BigBoats\Model\Coverings;


use Learn\BigBoats\Api\Covering;

class Standard implements Covering
{

}
