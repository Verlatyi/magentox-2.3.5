<?php


namespace Learn\BigBoats\Model\Types;

use Learn\BigBoats\Api\Type;

class Fisher implements Type
{
    public function getType()
    {
        return "Fisher";
    }
}
