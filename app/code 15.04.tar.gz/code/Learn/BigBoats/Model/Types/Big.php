<?php

namespace Learn\BigBoats\Model\Types;

use Learn\BigBoats\Api\Type;

class Big implements Type
{
    public function getType()
    {
        return "Big";
    }
}
