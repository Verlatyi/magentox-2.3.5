<?php

namespace Learn\BigBoats\Logger;


class Customer extends \Monolog\Logger
{

}