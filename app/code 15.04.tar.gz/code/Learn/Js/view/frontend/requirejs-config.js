
var config = {
  map: {
      '*': {
          jsfunction: 'Learn_Js/js/jsfunction',
          jswidget: 'Learn_Js/js/jswidget',
          jsobject: 'Learn_Js/js/jsobject',
      }
  },
  paths: {
      'logger': 'Learn_Js/js/logger',
      'counter': 'Learn_Js/js/counter',
  }
/*  shim: {
      'jswidget': {
          deps: ['jquery/ui']
      }*/
 // }
};
