<?php

namespace Learn\ModuleA\Api;

interface BoatInterface
{
    public function getBoatType();
}