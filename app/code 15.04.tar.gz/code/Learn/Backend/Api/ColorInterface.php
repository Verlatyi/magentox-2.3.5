<?php


namespace Learn\Backend\Api;


interface ColorInterface
{
    public function getColor();
}
