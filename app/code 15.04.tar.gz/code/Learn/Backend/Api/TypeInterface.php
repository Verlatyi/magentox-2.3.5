<?php


namespace Learn\Backend\Api;


interface TypeInterface
{
    public function getType();
}
