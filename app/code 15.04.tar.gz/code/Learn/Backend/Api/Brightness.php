<?php
/**
 * Created by PhpStorm.
 * User: dev
 * Date: 06.03.21
 * Time: 19:54
 */

namespace Learn\Backend\Api;


interface Brightness
{

}