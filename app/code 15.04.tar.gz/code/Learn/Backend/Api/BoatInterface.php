<?php

namespace Learn\Backend\Api;

interface BoatInterface
{
    public function getBoatType();

    public function getBoatColor();
}