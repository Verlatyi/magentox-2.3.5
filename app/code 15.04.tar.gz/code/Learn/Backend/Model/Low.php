<?php
/**
 * Created by PhpStorm.
 * User: dev
 * Date: 06.03.21
 * Time: 19:59
 */

namespace Learn\Backend\Model;


use Learn\Backend\Api\Brightness;

class Low implements Brightness
{

}