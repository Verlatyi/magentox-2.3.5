<?php
/**
 * Created by PhpStorm.
 * User: dev
 * Date: 06.03.21
 * Time: 19:58
 */

namespace Learn\Backend\Model;


use Learn\Backend\Api\Brightness;

class High implements Brightness
{

}