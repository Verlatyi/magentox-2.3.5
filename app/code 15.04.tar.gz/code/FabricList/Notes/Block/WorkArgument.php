<?php

namespace FabricList\Notes\Block;

use Magento\Framework\View\Element\Template\Context;

class WorkArgument extends \Magento\Framework\View\Element\Template
{
    public function __construct(Context $context)
    {
        parent::__construct($context);
    }
}
